def hello():
    return "Hello from foo!"
